import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-left-sidebar-plain',
  templateUrl: './left-sidebar-plain.component.html',
  styleUrls: ['./left-sidebar-plain.component.scss']
})
export class LeftSidebarPlainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
