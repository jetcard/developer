import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested1',
  templateUrl: './nested1.component.html',
  styleUrls: ['./nested1.component.scss']
})
export class Nested1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
